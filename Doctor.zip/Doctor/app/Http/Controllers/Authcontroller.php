<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class Authcontroller extends Controller
{
    public function rules($data)
    {
        $messages = [
            'email.required' => 'Please enter your email address',
            'email.exists' => 'Email already exists',
            'email.email' => 'Please enter a valid email address',
            'password.required' => 'password is required',
            'password.min' => 'password must be atleast 6 characters'

        ];

        $validator = validator::make($data, [
            'email' => 'required|email|exists:users',
            'password' => 'required'
        ], $messages);
    }
    public function savedoc(Request $request)
    {

        //$request->validator([
        //    'name' => 'required|string|regex:/^[a-zA-z],{3,16}/i',
        //    'email' => 'required|unique:users|regex:/(.+)@(.+)\.(.+)/i',
        //    'password' => 'required|min:6|',
        //]);
        $users = new User([
            'name' => $request->get('namae'),
            'email' => $request->get('email'),
            'password' => $request->get('password'),
            'user_type' => 'doctor'

        ]);




        $users->save();
        return redirect()->intended('/doctor/dashboard');
    }
}
