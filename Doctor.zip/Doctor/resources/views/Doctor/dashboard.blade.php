@section('title','dashboard')
@extends('Doctors.Layout.Doc.Header')

@section('content')
<h1>Doctor dashboard</h1>
@endsection